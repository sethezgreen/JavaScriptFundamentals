import { useState } from 'react'
import './App.css'
import UserForm from './components/userForm'

function App() {
  return (
    <>
      <UserForm/>
    </>
  )
}

export default App
